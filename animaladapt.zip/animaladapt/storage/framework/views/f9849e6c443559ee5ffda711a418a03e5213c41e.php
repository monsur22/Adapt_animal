<?php $__env->startSection('content'); ?>

<div class="page-content fade-in-up">



    <div class="ibox">
            <div class="ibox-head">
                    <div class="ibox-title">All Volunter List List</div>
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter"
                            style="margin-right: 60px;">
                        Create Post
                    </button>
                </div>
            <div class="ibox-body">
                    <table class="table table-striped table-bordered table-hover" id="example-table" cellspacing="0" width="100%">
                        <thead>
                                <tr>
                                        <th>SL</th>
                                        <th>Name</th>
                                        <th>Image</th>
                                        <th>Adress</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        
                
                                </tr>
                        </thead>
                      
                        <tbody>
                                <?php $i=1 ?>
                            <?php $__currentLoopData = $Volunteer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($datas->first_name); ?>&nbsp<?php echo e($datas->last_name); ?></td>
                             
                                <td><img src="<?php echo e(asset($datas->image)); ?>" height="50" width="50" >   </td>

                                <td><?php echo e($datas->address); ?></td>
                                
                                <td><?php echo e($datas->email); ?></td>
                                <td><?php echo e($datas->phone); ?></td>
                          
                           
                            
    
                            </tr>
        
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
                        </tbody>
                    </table>
                </div>
        </div>
        
</div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\animaladapt\resources\views/admin/pages/volunter.blade.php ENDPATH**/ ?>