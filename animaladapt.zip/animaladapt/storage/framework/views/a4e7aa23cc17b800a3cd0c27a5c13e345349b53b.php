 <nav class="page-sidebar" id="sidebar">
            <div id="sidebar-collapse">
                <div class="admin-block d-flex">
                  
                </div>
                <ul class="side-menu metismenu">
                    <li>
                        <a class="active" href="<?php echo e(url('/admin')); ?>"><i class="sidebar-item-icon fa fa-th-large"></i>
                            <span class="nav-label">Admin-Dashboard</span>
                        </a>
                    </li>
                    <li class="heading">FEATURES</li>
                    <li>
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-bookmark"></i>
                            <span class="nav-label">Category</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            <li><a class="" href="<?php echo e(url('/category')); ?>">Category List</a></li>                          
                         
                        </ul>
                    </li>
                    
                    <li>
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-bookmark"></i>
                            <span class="nav-label">All Post</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            <li><a class="" href="<?php echo e(url('/post-list')); ?>">Post List</a></li>                          
                         
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-bookmark"></i>
                            <span class="nav-label">User List</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            <li><a class="" href="<?php echo e(url('/user-list')); ?>">User List</a></li>                          
                         
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-bookmark"></i>
                            <span class="nav-label">All Request</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            <li><a class="" href="<?php echo e(url('/Request-On-Post')); ?>">Request List</a></li>                          
                         
                     </ul>
                    </li>
                    <li>
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-bookmark"></i>
                            <span class="nav-label">Volunteer Request</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            <li><a class="" href="<?php echo e(url('/volunteer-show')); ?>"> List</a></li>                          
                         
                     </ul>
                    </li>
                    <li>
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-bookmark"></i>
                            <span class="nav-label">Message</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            <li><a class="" href="<?php echo e(url('/contact/show')); ?>">Message List</a></li>                          
                                                    
                         
                        </ul>
                    </li>
                </ul>
            </div>
        </nav><?php /**PATH C:\xampp\htdocs\animaladapt\resources\views/admin/includes/slidebar.blade.php ENDPATH**/ ?>