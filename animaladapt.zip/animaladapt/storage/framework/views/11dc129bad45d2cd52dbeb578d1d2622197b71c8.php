<?php $__env->startSection('content'); ?>

<div class="page-content fade-in-up">



    <div class="ibox">
            <div class="ibox-head">
                    <div class="ibox-title">All Post List</div>
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter"
                            style="margin-right: 60px;">
                        Create Post
                    </button>
                </div>
            <div class="ibox-body">
                    <table class="table table-striped table-bordered table-hover" id="example-table" cellspacing="0" width="100%">
                        <thead>
                                <tr>
                                        <th>SL</th>
                                        <th>Title</th>
                                        <th>Category</th>
                                        <th>Image</th>
                                        <th>Gender</th>
                                        <th>User</th>
                                        <th>Action</th>
                
                                </tr>
                        </thead>
                      
                        <tbody>
                                <?php $i=1 ?>
                            <?php $__currentLoopData = $AdaptPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($datas->title); ?></td>
                                <td>
                                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($datas->category==$item->id): ?>
                                        <?php echo e($item->category_name); ?>

                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </td>
                                <td><img src="<?php echo e(asset($datas->image)); ?>" height="50" width="50" >
                                </td>
                                
                                <td><?php echo e($datas->gender); ?></td>
                                <td><?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($datas->user_id==$item->id): ?>
                                    <?php echo e($item->name); ?>

                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            
                            
        
        
                                <td>
                                  
                              
                                    <a href="<?php echo e(url('/mypost/delete/'.$datas->id)); ?>" class="btn btn-danger" title="Delete"onclick="return confirm('Are you sure to delete this?')">
                                        <span class="fa fa-trash font-14  "></span>
                                    </a>
        
                                </td>
                            </tr>
        
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
                        </tbody>
                    </table>
                </div>
        </div>
        
</div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\animaladapt\resources\views/admin/pages/all_post.blade.php ENDPATH**/ ?>