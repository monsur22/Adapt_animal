 <nav class="page-sidebar" id="sidebar">
            <div id="sidebar-collapse">
                <div class="admin-block d-flex">
                  
                </div>
                <ul class="side-menu metismenu">
                    <li>
                        <a class="active" href="<?php echo e(url('/admin')); ?>"><i class="sidebar-item-icon fa fa-th-large"></i>
                            <span class="nav-label">Dashboard</span>
                        </a>
                    </li>
                    <li class="heading">FEATURES</li>
                    <li>
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-bookmark"></i>
                            <span class="nav-label">Master Setup</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-id-badge"></i>
                            <span class="nav-label">Customer Setup</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            
                           
                          
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-user-circle"></i>
                            <span class="nav-label">Supplier Setup</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            

                           
                          
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-bookmark"></i>
                            <span class="nav-label">Account Setup</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            
                          
                        </ul>
                    </li>
                      
                     <li>
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-bookmark"></i>
                            <span class="nav-label">Voucher</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                                               
                            
                          
                        </ul>
                    </li>




                    <li>
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-bookmark"></i>
                            <span class="nav-label">Account Report</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            <li><a class="" href="<?php echo e(url('/chart-of-account')); ?>">Chart of Accounts </a></li>                          
                            <li><a class="" href="<?php echo e(url('/account-ledger')); ?>">Account Ledger</a></li>
                            <li><a class="" href="<?php echo e(url('/expence-statement')); ?>">Expense Statement</a></li>                          
                            <li><a class="" href="<?php echo e(url('/income-statement')); ?>">Income Statement</a></li>  
                            <li><a class="" href="<?php echo e(url('/expense-income-report')); ?>">Income & Expense Report</a></li>    
                            
                        </ul>
                    </li>
                   
                    <li>
                            <a href="javascript:;"><i class="sidebar-item-icon fa fa-bookmark"></i>
                                <span class="nav-label">User System</span><i class="fa fa-angle-left arrow"></i></a>
                            <ul class="nav-2-level collapse">
                                <li><a class="" href="<?php echo e(url('/user-login-logout-record')); ?>">Log In Out Record</a></li>                          
                                
                                
                            </ul>
                        </li>
                    
                  
                </ul>
            </div>
        </nav><?php /**PATH E:\xampp\htdocs\animaladapt\resources\views/admin/includes/slidebar.blade.php ENDPATH**/ ?>