<h3 class="text-center text-success">Replay your Massage</h3>


<p> Your Email ID:<b> <?php echo e(Session('email')); ?></b> </p>
<p> Your Subject :<b> <?php echo e(Session('subject')); ?></b> </p>
<p> Your Message:<b> <?php echo e(Session('message')); ?></b> </p>
<p> Replay From Admin:<b> <?php echo e(Session('replay_message')); ?></b> </p><?php /**PATH C:\xampp\htdocs\animaladapt\resources\views/admin/contact/send_replay.blade.php ENDPATH**/ ?>