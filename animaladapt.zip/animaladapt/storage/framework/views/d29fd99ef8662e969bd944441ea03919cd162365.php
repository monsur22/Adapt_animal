<header id="header" id="home">
    <div class="container main-menu">
        <div class="row align-items-center justify-content-between d-flex">
          <div id="logo">
          <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('public/home')); ?>/img/logo.png" alt="" title="" /></a>
          </div>
          <nav id="nav-menu-container">
            <ul class="nav-menu">
              <li class="menu-active"><a href="<?php echo e(url('/')); ?>">Home</a></li>
              <li><a href="<?php echo e(url('/cats')); ?>">Cats</a></li>
              <li><a href="<?php echo e(url('/dogs')); ?>">Dogs</a></li>
              <li><a href="<?php echo e(url('/volunteer')); ?>">Volunteer</a></li>
              <li><a href="<?php echo e(url('/about')); ?>">About Us</a></li>
              <li><a href="<?php echo e(url('/contact')); ?>">Contact</a></li>

              

        
                  
              
            <?php if(Auth::check() && Auth::user()->user_role == 'admin'): ?> 
                <li class="menu-has-children"><a class="form-control" href="<?php echo e(url('/user')); ?>"style="color:black;"><?php echo e(Auth::user()->name); ?></a></a>
                  <ul>
                    <li><a class="form-control" href="<?php echo e(url('/admin')); ?>"style="color:black;">My Account</a></li>
                  </ul>
              </li>
              <li>
                
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button class="form-control"type="submit">Logout</button>
                </form>	
                </li>
            
            <?php elseif(Auth::check() && Auth::user()->user_role == 'user'): ?> 
                  <li class="menu-has-children"><a class="form-control" href="<?php echo e(url('/user')); ?>"style="color:black;"><?php echo e(Auth::user()->name); ?></a></a>
                      <ul>
                        <li><a class="form-control" href="<?php echo e(url('/user')); ?>"style="color:black;">My Account</a></li>
                      </ul>
                  </li>
                  <li>
                  
                      <form method="POST" action="<?php echo e(route('logout')); ?>">
                          <?php echo csrf_field(); ?>
                          <button class="form-control"type="submit">Logout</button>
                      </form>	
                  </li>
            
            <?php else: ?>
                <li><a class="form-control" href="<?php echo e(url('/login')); ?>"style="color:black;">Login</a></li>
                <li><a class="form-control" href="<?php echo e(url('/register')); ?>"style="color:black;">Registraiton</a></li>
            <?php endif; ?>
            

         

            </ul>
          </nav><!-- #nav-menu-container -->
      

          	    		
        </div>
    </div>
  </header><!-- #header --><?php /**PATH C:\xampp\htdocs\animaladapt\resources\views/Home/includes/header.blade.php ENDPATH**/ ?>