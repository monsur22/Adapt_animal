<?php $__env->startSection('maincontent'); ?>
<!-- start banner Area -->

<section class="banner-area relative" id="home">	
        <div class="overlay overlay-bg"></div>
        <div class="container">				
            <div class="row d-flex align-items-center justify-content-center">
                <div class="about-content col-lg-12">
                    <h1 class="text-white">
                        Animal	Details			
                    </h1>	
                    <p class="text-white link-nav"><a href="<?php echo e(url('/')); ?>">Home </a>  
                        
                    </p>
                </div>	
            </div>
        </div>
    </section>
    <!-- End banner Area -->	
        
    <!-- Start cat-list Area -->
    <section class="cat-list-area section-gap">
        <div class="container">
            <div class="row">
                   
                    <div class="col-md-6" >
                        <div class="single-cat-list">
                   
                          <img src="<?php echo e(asset($data->image)); ?>" alt="" class="img-fluid"style="height: 500px;width:500px">
                             
                        </div>
                    </div>
                    <div class="col-md-6" >
                     
                    <h3 class="product-title"><?php echo e($data->title); ?></h3>
                                   
                    <p class="product-description"><?php echo e($data->description); ?></p>
                                    <h4 class="price">Gender: <span><?php echo e($data->gender); ?></span></h4>
                                    <p class="vote"><b>Contact Information:</b> <strong> <?php echo e($data->address); ?></strong></p>
                                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($data->user_id==$item->id): ?>
                                    
                                    <p class="vote"><strong>Post By: <?php echo e($item->name); ?></strong></p>
                                        
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   
                                  
                                   
                                <div class="action">
                                <form action="<?php echo e(url('/request-for-adapt')); ?>" method="post"enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="title"value="<?php echo e($data->title); ?>">
                                    <input type="hidden" name="post_id"value="<?php echo e($data->id); ?>">
                                    <input type="hidden" name="post_category"value="<?php echo e($data->category); ?>">
                                    <input type="hidden" name="post_image"value="<?php echo e($data->image); ?>">
                                    <input type="hidden" name="post_user_id"value="<?php echo e($data->user_id); ?>">
                                    <input type="hidden" name="post_address"value="<?php echo e($data->address); ?>">
                                    <?php if(Auth::check()): ?>
                                    <input class="primary-btn float-right" type="submit" name="submit" value="Adapt Request"> 
                                    <?php else: ?>
                                   <b class="btn-danger">!!For Send Adapt Request Log in First!!</b>
                                    
                                    <?php endif; ?>
                              
                                </form>
                                </div>
                                
                        </div>
             
               											
            </div>
        </div>	
    </section>      

    <!-- Start calltoaction Area -->
    <section class="calltoaction-area section-gap relative">
        <div class="container">
            <div class="overlay overlay-bg"></div>						
            <div class="row align-items-center justify-content-center">
                <h1 class="text-white">Want to help? Become a Volunteer</h1>
                <p class="text-white">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    Ut enim ad minim. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.
                </p>
                <div class="buttons d-flex flex-row">
                    <a href="#" class="primary-btn text-uppercase">View pdf details</a>
                    <a href="<?php echo e(url('/volunteer')); ?>" class="primary-btn text-uppercase">Register now</a>
                </div>
            </div>
        </div>	
    </section>
    <!-- End calltoaction Area -->				
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Home.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\animaladapt\resources\views/Home/pages/adnimal_by_id.blade.php ENDPATH**/ ?>