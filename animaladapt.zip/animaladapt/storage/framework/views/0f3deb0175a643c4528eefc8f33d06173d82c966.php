<?php $__env->startSection('content'); ?>

<div class="page-content fade-in-up">


    <div class="ibox">
            <div class="ibox-head">
                    <div class="ibox-title">My Adapt List</div>
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter"
                            style="margin-right: 60px;">
                        Create Post
                    </button>
                </div>
            <div class="ibox-body">
                    <table class="table table-striped table-bordered table-hover" id="example-table" cellspacing="0" width="100%">
                        <thead>
                                <tr>
                                        <th>SL</th>
                                        <th>Title</th>
                                        <th>Post ID</th>
                                        <th>Image</th>
                                        <th>Address</th>
                                        <th>Status</th>
                                        
                
                                </tr>
                        </thead>
                      
                        <tbody>
                                <?php $i=1 ?>
                            <?php $__currentLoopData = $RequestPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($datas->title); ?></td>
                                <td>
                                    
                                    <?php echo e($datas->post_id); ?>

                                </td>
                                <td><img src="<?php echo e(asset($datas->post_image)); ?>" height="50" width="50" >
                                </td>
                                
                                <td><?php echo e($datas->post_address); ?></td>
                            <td>
                                    <?php if($datas->status==1): ?>
                                    <b class="btn-success">Confirm</b>
                                    <?php endif; ?>

                                
                        </td>
                            
        
        
                                <td>
                                  
                                   
                                        
                                    
                                    
        
                                </td>
                            </tr>
        
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
                        </tbody>
                    </table>
                </div>
        </div>
        
</div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\animaladapt\resources\views/user/pages/myAdaptanimal.blade.php ENDPATH**/ ?>