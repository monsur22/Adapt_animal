 <nav class="page-sidebar" id="sidebar">
            <div id="sidebar-collapse">
                <div class="admin-block d-flex">
                  
                </div>
                <ul class="side-menu metismenu">
                    <li>
                        <a class="active" href="<?php echo e(url('/user')); ?>"><i class="sidebar-item-icon fa fa-th-large"></i>
                            <span class="nav-label">User-Dashboard</span>
                        </a>
                    </li>
                    <li class="heading">FEATURES</li>
                    <li>
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-user-circle"></i>
                            <span class="nav-label"> Setup</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            <li><a class="" href="<?php echo e(url('/')); ?>">My Profile</a></li>                          
                         
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-paw"></i>
                            <span class="nav-label">Adapt</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            <li><a class="" href="<?php echo e(url('/Adapt-list')); ?>">My Adapt</a></li>
                           
                          
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-bookmark"></i>
                            <span class="nav-label">Post Animal</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            <li><a class="" href="<?php echo e(url('/mypost')); ?>">My Post</a></li>                          
                            <li><a class="" href="<?php echo e(url('/request-my-post')); ?>">Request My Post</a></li>                          

                           
                          
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-bookmark"></i>
                            <span class="nav-label">Request</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            <li><a class="" href="<?php echo e(url('/my-request')); ?>">My Request</a></li>                          

                           
                          
                        </ul>
                    </li>
                    
                      
                     
                    
                  
                </ul>
            </div>
        </nav><?php /**PATH C:\xampp\htdocs\animaladapt\resources\views/user/includes/slidebar.blade.php ENDPATH**/ ?>