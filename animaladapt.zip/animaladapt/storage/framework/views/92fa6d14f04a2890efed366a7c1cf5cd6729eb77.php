<?php $__env->startSection('content'); ?>

<div class="page-content fade-in-up">


    <div class="ibox">
            <div class="ibox-head">
                    <div class="ibox-title">Message List</div>
                   
                </div>
            <div class="ibox-body">
                    <table class="table table-striped table-bordered table-hover" id="example-table" cellspacing="0" width="100%">
                        <thead>
                                <tr>
                                    <th>SID</th>
                                    <th>Subject</th>
                                    <th>Email</th>
                                    <th>Message</th>
                                    <th>Action</th>
                
                                </tr>
                        </thead>
                      
                        <tbody>
                                <?php $i=1 ?>
                            <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($datas->subject); ?></td>
                                <td><?php echo e($datas->email); ?></td>
                                <td><?php echo e($datas->message); ?></td>
                             
                               
                               
                                
                              
                            
                            
        
        
                                
                                    <td>  
                                        <a class="btn btn-primary" href="<?php echo e(url('/contact/replay/'.$datas->id)); ?>"><span class="fa fa-reply font-14"></span></a>
                                         <a href="<?php echo e(url('/contact/delete/'.$datas->id)); ?>" class="btn btn-danger" title="Delete"onclick="return confirm('Are you sure to delete this?')">
                                                    <span class="fa fa-trash font-14 "></span>
                                            </a>
                                  
                                    </td>
        
                                
                            </tr>
        
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
                        </tbody>
                    </table>
                </div>
        </div>
        
</div>




<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\animaladapt\resources\views/admin/contact/index.blade.php ENDPATH**/ ?>