<?php $__env->startSection('content'); ?>

<div class="page-content fade-in-up">



    <div class="ibox">
            <div class="ibox-head">
                    <div class="ibox-title">User  List</div>
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter"
                            style="margin-right: 60px;">
                        Create Post
                    </button>
                </div>
            <div class="ibox-body">
                    <table class="table table-striped table-bordered table-hover" id="example-table" cellspacing="0" width="100%">
                        <thead>
                                <tr>
                                        <th>SL</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        
                                        <th>Action</th>
                
                                </tr>
                        </thead>
                      
                        <tbody>
                                <?php $i=1 ?>
                            <?php $__currentLoopData = $User; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($datas->name); ?></td>
                             
                                

                                <td><?php echo e($datas->email); ?></td>
                                <td>
                                    
    
                                <a href="<?php echo e(url('//'.$datas->id)); ?>" class="btn btn-danger" title="Delete"onclick="return confirm('Are you sure to delete this?')">
                                    <span class="fa fa-trash font-14  "></span> </a>
                                </td>
                            
                           
                            
                   
                          
                           
                            
    
                            </tr>
        
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
                        </tbody>
                    </table>
                </div>
        </div>
        
</div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\animaladapt\resources\views/admin/pages/user_list.blade.php ENDPATH**/ ?>