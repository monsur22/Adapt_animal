<footer class="footer-area">
    <div class="container">
        <div class="row pt-120 pb-80">
            <div class="col-lg-4 col-md-6">
                <div class="single-footer-widget">
                    <h6>About Us</h6>
                    <p>
                        Few would argue that, despite the advanc ements off eminism over the past three decades, women still face a double standard when it comes to their behavior. While men’s borderline-inappropriate behavior. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    </p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="single-footer-widget">
                    <h6>Useful Links</h6>
                    <div class="row">
                        <ul class="col footer-nav">
                            <li><a href="#">Home</a></li>
                            <li><a href="#">Service</a></li>
                            <li><a href="#">About</a></li>
                            <li><a href="#">Case Study</a></li>
                        </ul>
                        <ul class="col footer-nav">
                            <li><a href="#">Pricing</a></li>
                            <li><a href="#">Team</a></li>
                            <li><a href="#">Blog</a></li>
                        </ul>									
                    </div>
                </div>
            </div>						
            <div class="col-lg-4  col-md-6">
                <div class="single-footer-widget mail-chimp">
                    <h6 class="mb-20">Contact Us</h6>
                    <ul class="list-contact">
                        <li class="flex-row d-flex">
                            <div class="icon">
                                <span class="lnr lnr-home"></span>
                            </div>
                            <div class="detail">
                                <h4>Binghamton, New York</h4>
                                <p>
                                    4343 Hinkle Deegan Lake Road
                                </p>
                            </div>	
                        </li>
                        <li class="flex-row d-flex">
                            <div class="icon">
                                <span class="lnr lnr-phone-handset"></span>
                            </div>
                            <div class="detail">
                                <h4>00 (953) 9865 562</h4>
                                <p>
                                    Mon to Fri 9am to 6 pm
                                </p>
                            </div>	
                        </li>
                        <li class="flex-row d-flex">
                            <div class="icon">
                                <span class="lnr lnr-envelope"></span>
                            </div>
                            <div class="detail">
                                <h4>support@colorlib.com</h4>
                                <p>
                                    Send us your query anytime!
                                </p>
                            </div>	
                        </li>																		
                    </ul>
                </div>
            </div>						
        </div>
    </div>
    <div class="copyright-text">
        <div class="container">
            <div class="row footer-bottom d-flex justify-content-between">
                <p class="col-lg-8 col-sm-6 footer-text m-0 text-white"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved By Bugfree 
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                <div class="col-lg-4 col-sm-6 footer-social">
                    <a href="#"><i class="fa fa-facebook"></i></a>
                    <a href="#"><i class="fa fa-twitter"></i></a>
                    <a href="#"><i class="fa fa-dribbble"></i></a>
                    <a href="#"><i class="fa fa-behance"></i></a>
                </div>
            </div>						
        </div>
    </div>
</footer>