 <nav class="page-sidebar" id="sidebar">
            <div id="sidebar-collapse">
                <div class="admin-block d-flex">
                  
                </div>
                <ul class="side-menu metismenu">
                    <li>
                        <a class="active" href="{{url('/user')}}"><i class="sidebar-item-icon fa fa-th-large"></i>
                            <span class="nav-label">User-Dashboard</span>
                        </a>
                    </li>
                    <li class="heading">FEATURES</li>
                    <li>
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-user-circle"></i>
                            <span class="nav-label"> Setup</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            <li><a class="" href="{{url('/')}}">My Profile</a></li>                          
                         
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-paw"></i>
                            <span class="nav-label">Adapt</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            <li><a class="" href="{{url('/')}}">My Adapt</a></li>
                           
                          
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-bookmark"></i>
                            <span class="nav-label">Post Animal</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            <li><a class="" href="{{url('/')}}">My Post</a></li>                          

                           
                          
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-bookmark"></i>
                            <span class="nav-label">Request</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            <li><a class="" href="{{url('/')}}">My Request</a></li>                          

                           
                          
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-envelope"></i>
                            <span class="nav-label">Massage</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            <li><a class="" href="{{url('/')}}">List</a></li>                          
                            <li><a class="" href="{{url('/')}}">Send</a></li>                          
                       
                          
                        </ul>
                    </li>
                      
                     {{-- <li>
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-bookmark"></i>
                            <span class="nav-label">Voucher</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                                               
                            <li><a class="" href="{{url('/payment-voucher')}}">Payment Voucher</a></li>                          
                            <li><a class="" href="{{url('/collection-voucher')}}">Collection Voucher</a></li>
                            <li><a class="" href="{{url('/expence-voucher')}}">Expence Voucher</a></li>
                            <li><a class="" href="{{url('/income-voucher')}}">Income Voucher</a></li>
                          
                        </ul>
                    </li>




                    <li>
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-bookmark"></i>
                            <span class="nav-label">Account Report</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            <li><a class="" href="{{url('/chart-of-account')}}">Chart of Accounts </a></li>                          
                            <li><a class="" href="{{url('/account-ledger')}}">Account Ledger</a></li>
                            <li><a class="" href="{{url('/expence-statement')}}">Expense Statement</a></li>                          
                            <li><a class="" href="{{url('/income-statement')}}">Income Statement</a></li>  
                            <li><a class="" href="{{url('/expense-income-report')}}">Income & Expense Report</a></li>    
                           
                        </ul>
                    </li>
                   
                    <li>
                            <a href="javascript:;"><i class="sidebar-item-icon fa fa-bookmark"></i>
                                <span class="nav-label">User System</span><i class="fa fa-angle-left arrow"></i></a>
                            <ul class="nav-2-level collapse">
                                <li><a class="" href="{{url('/user-login-logout-record')}}">Log In Out Record</a></li>                          
                                
                                
                            </ul>
                    </li> --}}
                    
                  
                </ul>
            </div>
        </nav>