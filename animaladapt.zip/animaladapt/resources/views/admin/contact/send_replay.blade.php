<h3 class="text-center text-success">Replay your Massage</h3>


<p> Your Email ID:<b> {{  Session('email')  }}</b> </p>
<p> Your Subject :<b> {{  Session('subject')  }}</b> </p>
<p> Your Message:<b> {{  Session('message')  }}</b> </p>
<p> Replay From Admin:<b> {{  Session('replay_message')  }}</b> </p>